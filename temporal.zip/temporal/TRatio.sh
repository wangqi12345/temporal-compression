#!/bin/bash




entryBitNum=("3" "4" "4" "5" "5" "5" "5" "5" "5")
entryNum=("7" "10" "13" "16" "19" "22" "25" "28" "31")




				
				
					formatFile="/home/wangqi/yangkai/plt/data/beijing/trajectories/T-Drive/new/013-new-format/format.txt"
					tcodingFile="/home/wangqi/yangkai/plt/result/t_coding/13/13.txt"
					ratioFile="/home/wangqi/yangkai/plt/ratio/t/13/13.txt"
					echo $ratioFile
					./e_t_ratio $formatFile $tcodingFile $ratioFile
				
			

