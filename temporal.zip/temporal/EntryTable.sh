#!/bin/bash


nodeFile=("/home/wangqi/yangkai/plt/data/beijing/roadnetwork/WA_Nodes.txt")

edgeFile=("/home/wangqi/yangkai/plt/data/beijing/roadnetwork/WA_Edges.txt")

geoFile=("/home/wangqi/yangkai/plt/data/beijing/roadnetwork/WA_EdgeGeometry.txt")

edge2entryFile=("/home/wangqi/yangkai/plt/data/beijing/index/beijing_edge2entry_table.txt")

for i in {0..0}
do
	echo ${edge2entryFile[$i]}
	./e_edge2entry_table ${nodeFile[$i]} ${edgeFile[$i]} ${geoFile[$i]} ${edge2entryFile[$i]}
done

