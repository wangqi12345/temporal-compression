#!/bin/bash


program=("EntryTable" "TCoding" "TRatio")


				for i in {0..2}
				do
					tmpProgram=${program[$i]}
					tmpProgram+=".sh"
					./$tmpProgram 
				done
			
