#!/bin/bash

nodeFile=("/home/wangqi/yangkai/plt/data/beijing/roadnetwork/WA_Nodes.txt")

edgeFile=("/home/wangqi/yangkai/plt/data/beijing/roadnetwork/WA_Edges.txt")

geoFile=("/home/wangqi/yangkai/plt/data/beijing/roadnetwork/WA_EdgeGeometry.txt")

entryTable=("/home/wangqi/yangkai/plt/data/beijing/index/beijing_edge2entry_table.txt")


entryBitNum=("3" "4" "4" "5" "5" "5" "5" "5" "5")
entryNum=("7" "10" "13" "16" "19" "22" "25" "28" "31")


				
				
					connFile="/home/wangqi/yangkai/plt/dataset/connected/1t3r/connect.txt"
					tcodingFile="/home/wangqi/yangkai/plt/result/t_coding/13/13.txt"
					echo $tcodingFile
					./e_t_coding ${nodeFile[0]} ${edgeFile[0]} ${geoFile[0]} ${entryTable[0]} $connFile $tcodingFile
				
	



